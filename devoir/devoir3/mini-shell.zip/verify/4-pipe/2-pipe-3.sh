cat /etc/passwd | grep "/bin/bash" | cut -d ":" -f 1
exit

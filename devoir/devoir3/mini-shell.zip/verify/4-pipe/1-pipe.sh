cat /etc/hosts | grep 127.0.0.1
exit

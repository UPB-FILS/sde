ls
exit

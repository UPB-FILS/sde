cd /
exit

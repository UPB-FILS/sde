cat /proc/mounts
exit

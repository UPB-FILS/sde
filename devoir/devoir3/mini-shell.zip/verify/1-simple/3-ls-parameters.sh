ls -l
exit

ls /software
exit

uname -a
exit

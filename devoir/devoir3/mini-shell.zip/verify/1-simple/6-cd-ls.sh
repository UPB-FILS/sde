cd /
ls
exit

ls ; uname
exit

sleep 1 && echo "SDE" & sleep 0.5 && echo "Hello" & sleep 0.6 && echo "from" & sleep 1.1
exit

true || ls /
false || ls /bin
exit

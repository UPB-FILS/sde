true && ls /sbin
false && ls /boot
exit

cat /proc/filesystems; uname -a ; ls
exit

echo "script" > test.out
cat test.out
exit

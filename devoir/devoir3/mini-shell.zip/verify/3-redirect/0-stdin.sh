cat < /etc/passwd
exit 

echo "script" > test.out
echo "script" >> test.out
cat test.out
exit

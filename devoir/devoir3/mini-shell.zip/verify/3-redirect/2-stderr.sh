ls /inexistent 2> text.err
cat text.err
exit
